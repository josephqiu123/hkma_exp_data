from sklearn.model_selection import GridSearchCV, PredefinedSplit
import numpy as np
import xgboost as xgb
from sklearn.metrics import accuracy_score

def evaluate_window(X_train_full, y_train_full, X_test, y_test, tune_params=True, val_ratio=0.2):
    """
    在 Grid Search 调参时使用时间序列式划分（前部分训练，后部分验证）
    """

    # ---------- Step 1: 手动划分训练/验证 ----------
    n_samples = len(X_train_full)
    split_index = int(n_samples * (1 - val_ratio))

    X_train, X_val = X_train_full[:split_index], X_train_full[split_index:]
    y_train, y_val = y_train_full[:split_index], y_train_full[split_index:]

    # PredefinedSplit: -1 表示训练集，0 表示验证集
    test_fold = np.concatenate([
        np.full(split_index, -1),   # 前面部分 -> 训练
        np.zeros(n_samples - split_index)  # 后面部分 -> 验证
    ])
    ps = PredefinedSplit(test_fold)

    # ---------- Step 2: 模型与参数网格 ----------
    model = xgb.XGBClassifier(
        booster='gbtree',
        random_state=42,
        use_label_encoder=False,
        eval_metric='logloss'
    )

    param_grid = {
        'n_estimators': [50, 100, 200],
        'max_depth': [3, 5, 7],
        'subsample': [0.6, 0.8, 1.0],
        'colsample_bytree': [0.6, 0.8, 1.0],
        'eta': [0.05, 0.1, 0.3],
    }

    # ---------- Step 3: Grid Search ----------
    if tune_params:
        print("🔍 Running GridSearchCV with predefined time-based validation split ...")
        search = GridSearchCV(
            model,
            param_grid=param_grid,
            scoring='accuracy',
            cv=ps,          # 👈 关键：使用自定义划分
            verbose=1,
            n_jobs=-1
        )
        search.fit(X_train_full, y_train_full)
        model = search.best_estimator_
        print(f"✅ Best Params: {search.best_params_}")
    else:
        model.fit(X_train, y_train)

    # ---------- Step 4: 评估 ----------
    y_pred_test = model.predict(X_test)
    y_pred_train = model.predict(X_train)

    test_acc = accuracy_score(y_test, y_pred_test)
    train_acc = accuracy_score(y_train, y_pred_train)

    print(f"Training Accuracy : {train_acc:.4f}")
    print(f"Testing Accuracy  : {test_acc:.4f}")
    return test_acc
